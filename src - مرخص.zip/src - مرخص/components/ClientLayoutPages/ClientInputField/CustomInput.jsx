import { useEffect } from "react";

export default function CustomInput({
  title,
  id,
  value,
  onChange,
  type = "text",
  direction = "rtl",
  required = false,
  isDisabled = false,
  max = "",
  min = "",
  className = "",
  options,
}) {
  const inputProps = {
    id,
    name: id,
    type,
    className: `block w-full px-2 py-1 mt-2 text-white border rounded-md bg-zinc-700 
                disabled:bg-zinc-600 border-gray-600 focus:border-yellow-500 
                focus:outline-none focus:!ring-0 disabled:bg-gray-200 dark:disabled:bg-gray-600 h-9 placeholder:text-right placeholder:rtl`,
    style: { direction },
    value,
    onChange: (e) => onChange(e.target),
    required,
    disabled: isDisabled,
    autoComplete: "off",
    ...(type === "text" && max ? { maxLength: max } : {}),
    ...(type === "text" && min ? { minLength: min } : {}),
    ...(type === "number" && max ? { max } : {}),
    ...(type === "number" && min ? { min } : {}),
  };

  // قائمة المحافظات السورية
  const syrianCities = [
    "دمشق",
    "ريف دمشق",
    "قلمون",
    "حمص",
    "ريف حمص",
    "طرطوس",
    "ريف طرطوس",
    "حماه",
    "ريف حماه",
    "درعا",
    "اللاذقية",
    "ريف اللاذقية",
    "حلب",
    "ريف حلب",
    "القامشلي",
    "الرقة",
    "دير الزور",
    "البوكمال",
    "الحسكة",
  ];

  useEffect(() => {
    if (
      type === "number" &&
      min &&
      (value === "" || value === undefined || value === null)
    ) {
      onChange({ name: id, value: min });
    }
  }, []);

  return (
    <div className={`relative ${className}`}>
      <label htmlFor={id} className="text-sm font-medium text-gray-200">
        {title}
      </label>
      {required && (
        <span className="text-red-600 font-bold dark:text-green-600">*</span>
      )}

      {type == "select" ? (
        <select
          id={id}
          name={id}
          value={value}
          onChange={(e) => onChange(e.target)}
          className="block w-full px-2 mt-2 text-white border rounded-md bg-zinc-700  border-gray-600 focus:border-yellow-500 
                     focus:outline-none focus:!ring-0 h-9"
          disabled={isDisabled}
          required
        >
          <option value="">قم بالتحديد</option>
          {options &&
            options?.split("-").map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
        </select>
      ) : id === "city" ? (
        <select
          id={id}
          name={id}
          value={value}
          onChange={(e) => onChange(e.target)}
          className="block w-full px-2 mt-2 text-white border rounded-md bg-zinc-700  border-gray-600 focus:border-yellow-500 
                     focus:outline-none focus:!ring-0 h-9"
          disabled={isDisabled}
          required
        >
          <option value="">اختر المحافظة</option>
          {syrianCities.map((city) => (
            <option key={city} value={city}>
              {city}
            </option>
          ))}
        </select>
      ) : (
        <input
          {...inputProps}
          onWheel={(e) => e.target.blur()}
          placeholder={
            type === "number"
              ? min && max
                ? `   أقل قيمة (${min}) - أكثر قيمة (${max})`
                : min
                ? `   أقل قيمة (${min})`
                : max
                ? `   أكثر قيمة (${max})`
                : ""
              : ""
          }
        />
      )}
    </div>
  );
}
