import React from "react";
import "./MainContent.scss";
export default function MainContent({ children }) {
  return (
    <section
      className={`grid grid-cols-1 min-h-screen bg-gradient-to-br from-green-50 via-white to-green-100 dark:from-gray-900 dark:via-gray-950 dark:to-black  main-content-dashboard`}
    >
      {children}
    </section>
  );
}
