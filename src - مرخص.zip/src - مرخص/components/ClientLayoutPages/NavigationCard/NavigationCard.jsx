import { image_host } from "config/api_host";
import { useState } from "react";
import { Link } from "react-router-dom";

export default function NavigationCard({
  image,
  name,
  link,
  is_available = true,
}) {
  const [loaded, setLoaded] = useState(false);
  // const navigate = useViewTransitionNavigate();

  return (
    <Link
      to={is_available ? link : "#"}
      onClick={(e) => {
        if (!is_available) {
          e.preventDefault(); // يمنع الانتقال
        }
      }}
      className={`w-full relative grid max-w-80 mx-auto ${
        is_available ? "cursor-pointer" : "cursor-not-allowed"
      } group`}
    >
      {!is_available && (
        <div className="absolute px-4 py-2 z-20 bg-yellow-500 rounded-2xl">
          <h1 className="text-center font-bold text-sm text-zinc-900">
            غير متوفر
          </h1>
        </div>
      )}

      {/* Skeleton Placeholder */}
      {!loaded && (
        <div className="w-full max-w-[268px] h-[100px] md:h-[151px] mb-2 mx-auto bg-gray-600 animate-pulse rounded-2xl"></div>
      )}

      {/* الصورة مع إخفائها حتى يتم تحميلها */}
      <img
        src={`${image_host}${image}`}
        alt={`${name}-image`}
        className={`${
          !is_available ? "grayscale" : "group-hover:scale-105"
        } w-full max-w-[268px] h-full max-h-[151px] mx-auto  transition-transform duration-300 ${
          loaded ? "block" : "hidden"
        }`}
        onLoad={() => setLoaded(true)}
      />
      <h5 className="text-center font-bold text-white text-sm">{name}</h5>
    </Link>
  );
}
