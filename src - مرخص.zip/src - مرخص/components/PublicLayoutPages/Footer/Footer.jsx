import { __APP_NAME__ } from "config/static";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <div
      className="self-end flex justify-center w-full mt-5 md:px-2  bg-white/70 dark:bg-gray-900/50
          backdrop-blur-xl
          border-t-2 dark:border-white/10 border-black/10
          shadow-lg"
    >
      <footer
        className="
          w-full max-w-6xl h-16 px-6 py-2 mx-auto
          flex items-center
         
          md:rounded-t-2xl_
        "
      >
        <div className="w-full flex flex-col md:flex-row items-center justify-center md:justify-between gap-2">
          {/* App Name */}
          <span className="text-sm font-bold text-gray-700 dark:text-gray-300 text-center">
            <a
              href="https://www.facebook.com/share/1FRJ4V9uTN/"
              target="_blank"
              rel="noopener noreferrer"
              className="
                text-green-500/90
                hover:text-green-400
                hover:underline
                transition
              "
            >
              {__APP_NAME__}
            </a>{" "}
            1.0.1
          </span>
          <span className="text-sm font-bold text-gray-700 dark:text-gray-300 text-center">
            <Link
              to="/privacy-policy"
              rel="noopener noreferrer"
              className="
                text-green-500/90
                hover:text-green-400
                hover:underline
                transition
              "
            >
              سياسة الاستخدام والخصوصية
            </Link>{" "}
          </span>

          {/* Optional credit (جاهز للتفعيل) */}
          {/*
          <span className="text-sm font-bold text-gray-600 dark:text-gray-400">
            تصميم وتطوير{" "}
            <a
              href="https://wa.me/963960062941"
              target="_blank"
              className="text-green-500/80 hover:underline"
            >
              byRings
            </a>
          </span>
          */}
        </div>
      </footer>
    </div>
  );
}
