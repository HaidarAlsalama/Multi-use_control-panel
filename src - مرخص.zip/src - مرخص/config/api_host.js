// export const api_host = "http://localhost:8000/api/";
// export const image_host = "http://localhost:8000";

export const api_host = "https://api.almohtaref.sy/api/";
export const image_host = "https://api.almohtaref.sy";

