export async function deriveKey(password, salt) {
    const keyMaterial = await window.crypto.subtle.importKey(
        "raw",
        new TextEncoder().encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return await window.crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"]
    );
}

export async function encryptData(data, password) {
    const salt = window.crypto.getRandomValues(new Uint8Array(16)); // Salt عشوائي
    const key = await deriveKey(password, salt);
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // IV عشوائي

    const encrypted = await window.crypto.subtle.encrypt(
        { name: "AES-GCM", iv },
        key,
        new TextEncoder().encode(data)
    );

    return {
        encryptedData: Array.from(new Uint8Array(encrypted)), // تحويل الـ Buffer إلى Array لتخزينه بسهولة
        salt: Array.from(salt),
        iv: Array.from(iv),
    };
}

export async function decryptData(encryptedData, password, salt, iv) {
    const key = await deriveKey(password, new Uint8Array(salt));

    const decrypted = await window.crypto.subtle.decrypt(
        { name: "AES-GCM", iv: new Uint8Array(iv) },
        key,
        new Uint8Array(encryptedData)
    );

    return new TextDecoder().decode(decrypted);
}
