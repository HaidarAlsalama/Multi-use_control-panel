import { _iv, _secretKey } from "./encrypt";
import CryptoJS from "crypto-js";

const secretKey = CryptoJS.enc.Utf8.parse(_secretKey);
const iv = CryptoJS.enc.Utf8.parse(_iv);

// تشفير البيانات
export function encryptData(data) {
  const encrypted = CryptoJS.AES.encrypt(
    CryptoJS.enc.Utf8.parse(data),
    secretKey,
    { iv: iv, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 }
  );
  return encrypted.toString();
}

// فك تشفير البيانات
export function decryptData(encryptedData) {
  const decrypted = CryptoJS.AES.decrypt(encryptedData, secretKey, {
    iv: iv,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}

export const formatPhoneDisplay = (phone) => {
  // حذف كل الرموز
  let cleaned = phone.replace(/\D/g, "");

  // إزالة صفر البداية إن وجد
  if (cleaned.startsWith("0")) {
    cleaned = cleaned.slice(1);
  }

  // التأكد من وجود كود الدولة
  if (!cleaned.startsWith("963")) {
    cleaned = "963" + cleaned;
  }

  // الآن التنسيق للعرض
  const country = "+963";
  const code = cleaned.slice(3, 6);
  const part1 = cleaned.slice(6, 9);
  const part2 = cleaned.slice(9, 12);

  return `${country} ${code} ${part1} ${part2}`;
};
