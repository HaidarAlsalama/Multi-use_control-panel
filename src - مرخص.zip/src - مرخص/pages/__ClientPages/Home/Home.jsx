import { Spinner } from "components";
import Container from "components/ClientLayoutPages/Container/Container";
import LogoSpinner from "components/Spinner/LogoSpinner";
import { useEffect } from "react";
import { FcManager } from "react-icons/fc";
import { Link, useNavigate } from "react-router-dom";

const cards = [
  {
    title: "تحويل رصيد",
    description: "إدارة عمليات التحويل",
    url: "abili",
    icon: FcManager,
  },
  {
    title: "تحويل رصيد جملة",
    description: "إدارة عمليات التحويل الجملة",
    url: "abili-jomla",
    icon: FcManager,
  },
];

export default function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    navigate("/my-account/abili");
  }, [navigate]);

  return <LogoSpinner page />;
  return (
    <Container>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 max-w-7xl mx-auto">
        {cards.map((card) => (
          <NavigationCard key={card.url} data={card} />
        ))}
      </div>
    </Container>
  );
}

function NavigationCard({ data }) {
  return (
    <Link
      to={data.url}
      className="group relative flex items-start w-full h-[120px] p-5 rounded-[2rem] 
                   bg-gradient-to-br from-green-50 via-white to-green-100 dark:from-gray-900 dark:via-gray-950 dark:to-black backdrop-blur-md 
                   border border-black/15 dark:border-white/10 
                   shadow-[0_4px_20px_rgba(0,0,0,0.03)] 
                   hover:shadow-[0_20px_40px_rgba(0,0,0,0.08)] 
                   hover:-translate-y-1 transition-all duration-500 overflow-hidden"
    >
      {/* تأثير الضوء عند الـ Hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-mainLight/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

      <div className="relative z-10 flex  justify-between h-full w-full">
        <div>
          <h5 className="text-lg font-bold text-gray-800 dark:text-white group-hover:text-mainLight transition-colors duration-300">
            {data.title}
          </h5>
          <p className="text-[12px] font-medium text-gray-500 dark:text-gray-400 mt-1 max-w-[180px] leading-tight">
            {data.description || ""}
          </p>
        </div>
        {/* الأيقونة بتصميم عصري */}
        <div className="opacity-50 group-hover:opacity-100 group-hover:scale-110 group-hover:-rotate-12 transition-all duration-500 transform-gpu">
          <data.icon className="m-auto text-7xl" />
        </div>
      </div>

      {/* خط ديكوري صغير يظهر عند التحويم */}
      <div className="absolute bottom-0 right-0 w-0 h-1 bg-mainLight group-hover:w-full transition-all duration-700" />
    </Link>
  );
}
