import { useClientPOS, useCreateOrderPos } from "api/Client/pos";
import { Spinner } from "components";
import {
  ArrowRightLeft,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  Send,
  Smartphone,
  Wallet,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

const PRODUCT_TYPE_MAP = {
  مسبق: "prepaid",
  لاحق: "postpaid",
  كاش: "cash",
};

const TRANSFER_TYPE_LABEL = {
  prepaid: "مسبق",
  postpaid: "لاحق",
  cash: "كاش",
};

const RaseedJomla = () => {
  const { data: productData, isLoading } = useClientPOS();
  const {
    mutate: createPos,
    isPending: IsPending,
    isSuccess: IsSuccess,
  } = useCreateOrderPos();
  const [operator, setOperator] = useState("empty");
  const [transferType, setTransferType] = useState("");
  const [amount, setAmount] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");

  const [code, setCode] = useState("");

  const operatorColors = {
    empty: "from-green-600 to-green-500",
    SYRIATEL: "from-red-600 to-red-500",
    MTN: "from-yellow-500 to-yellow-400",
  };

  // تحويل operator إلى uppercase لمطابقة المفاتيح
  const selectedOperatorKey = operator.toUpperCase();

  // المنتجات المتاحة حسب المشغل
  const productsByOperator = useMemo(() => {
    if (!productData || selectedOperatorKey === "EMPTY") return [];
    return productData[selectedOperatorKey] || [];
  }, [productData, selectedOperatorKey]);

  // أنواع التحويل المتوفرة
  const availableTransferTypes = useMemo(() => {
    return productsByOperator.map((p) => ({
      ...p,
      transferType: PRODUCT_TYPE_MAP[p.name] || "unknown",
    }));
  }, [productsByOperator]);

  // المنتج المختار حسب نوع التحويل
  const selectedProduct = availableTransferTypes.find(
    (p) => p.transferType === transferType,
  );

  // حقول المنتج الديناميكية
  const fields = selectedProduct ? JSON.parse(selectedProduct.fields) : [];

  const handleTransfer = (e) => {
    e.preventDefault();

    if (!selectedProduct) {
      console.warn("No product selected");
      return;
    }

    const payload = {
      number: phoneNumber,
      // operator: selectedOperatorKey, // SYRIATEL | MTN
      // transferType, // prepaid | postpaid | cash
      quantity: Number(amount),
      // unit_price: Number(selectedProduct.price),
      // total: Number(amount) * Number(selectedProduct.price),
      product_id: selectedProduct.id, // ⭐ المهم
      // product_name: selectedProduct.name,
      // currency: selectedProduct.currency || "S.P",
    };

    console.log("FORM DATA:", payload);

    // لاحقًا:
    // await submitTransfer(payload)
    createPos(payload);
  };

  useEffect(() => {
    console.log("Products:", productData);
    console.log("Selected operator:", operator);
    console.log("Available transfer types:", availableTransferTypes);
  }, [productData, operator, availableTransferTypes]);

  useEffect(() => {
    if (phoneNumber.length >= 3) {
      if (
        phoneNumber.startsWith("093") ||
        phoneNumber.startsWith("099") ||
        phoneNumber.startsWith("098")
      ) {
        setOperator("syriatel");
      } else if (
        phoneNumber.startsWith("094") ||
        phoneNumber.startsWith("095") ||
        phoneNumber.startsWith("096")
      ) {
        setOperator("mtn");
      } else {
        setOperator("");
      }
    } else {
      setOperator("");
    }
  }, [phoneNumber]);

  // استخراج حقل quantity مرة واحدة
  const quantityField = useMemo(() => {
    if (!selectedProduct?.fields) return null;

    try {
      const parsed = JSON.parse(selectedProduct.fields);
      return parsed.find((f) => f.fieldId === "quantity") || null;
    } catch (e) {
      return null;
    }
  }, [selectedProduct]);

  return (
    <div
      dir="rtl"
      className="h-full flex items-center justify-center p-0 md:p-8 
         text-slate-800 dark:text-white transition-all duration-500 relative overflow-hidden"
    >
      {/* Glow */}
      <div
        className={`absolute -top-24 -left-24 w-[40%] h-[40%] rounded-full blur-[120px] opacity-20
          ${
            selectedOperatorKey === "SYRIATEL"
              ? "bg-red-600"
              : selectedOperatorKey === "MTN"
                ? "bg-yellow-500"
                : "bg-green-500"
          }
        `}
      />
      <div
        className={`absolute -bottom-24 -right-24 w-[40%] h-[40%] rounded-full blur-[120px] opacity-20
          ${
            selectedOperatorKey === "SYRIATEL"
              ? "bg-orange-600"
              : selectedOperatorKey === "MTN"
                ? "bg-yellow-300"
                : "bg-green-400"
          }
        `}
      />

      <div
        className="w-full max-w-2xl p-4 md:p-10 md:rounded-[2.5rem] border
        bg-white/70 backdrop-blur-xl border-white/20
        dark:bg-white/10 dark:border-white/10
        shadow-[0_8px_32px_0_rgba(0,0,0,0.25)]
        relative z-10_"
      >
        {/* Header */}
        <div className="flex justify-between items-center mb-10">
          <div className="flex items-center gap-3">
            <div
              className={`p-3 rounded-2xl bg-gradient-to-br ${
                operatorColors[selectedOperatorKey] || operatorColors["empty"]
              }`}
            >
              <ArrowRightLeft className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black">تحويل الرصيد الجملة</h1>
              <p className="text-xs opacity-50 font-bold">
                إدارة عمليات التحويل
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleTransfer} className="space-y-8">
          {/* Operator */}
          <div className="grid grid-cols-2 gap-4">
            {["syriatel", "mtn"].map((op) => (
              <button
                key={op}
                type="button"
                disabled={phoneNumber >= 3 && operator != ""}
                onClick={() => {
                  setOperator(op);
                  setTransferType(""); // إعادة تعيين النوع عند تغيير المشغل
                  setAmount("");
                }}
                className={`
                      p-4 rounded-3xl relative border-2 flex flex-col items-center gap-2 transition-all
                      ${
                        operator === op
                          ? op === "syriatel"
                            ? "border-red-500 bg-red-500/10"
                            : "border-yellow-500 bg-yellow-500/10"
                          : "border-transparent bg-black/10 dark:bg-white/5 hover:bg-black/20 dark:hover:bg-white/10"
                      }
                    `}
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center font-black
                        ${
                          op === "syriatel"
                            ? "bg-red-600 text-white"
                            : "bg-yellow-500 text-black"
                        }`}
                >
                  {op === "syriatel" ? "S" : "M"}
                </div>
                <span className="font-black text-sm uppercase">
                  {op === "syriatel" ? "Syriatel" : "MTN"}
                </span>
                {operator === op && (
                  <CheckCircle2
                    className={`w-5 h-5 absolute top-4 left-4 ${
                      op === "syriatel" ? "text-red-500" : "text-yellow-500"
                    }`}
                  />
                )}
              </button>
            ))}
          </div>
          {/* Phone */}
          <div className="flex flex-col gap-1">
            <div className="flex flex-col gap-1">
              <label>الرقم</label>
              <input
                type="tel"
                placeholder="09xx xxx xxx"
                value={phoneNumber}
                maxLength={10}
                minLength={10}
                required
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full px-5 py-4 rounded-xl border outline-none
              bg-white border-gray-200
              dark:bg-black/20 dark:border-white/10"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label>الكود</label>
              <input
                type="tel"
                placeholder="xxx xxx"
                value={code}
                minLength={4}
                required
                onChange={(e) => setCode(e.target.value)}
                className="w-full px-5 py-4 rounded-xl border outline-none
              bg-white border-gray-200
              dark:bg-black/20 dark:border-white/10"
              />
            </div>
          </div>

          {/* Transfer Type */}
          <div className="bg-black/10 dark:bg-black/20 p-1.5 rounded-2xl flex gap-1">
            {["prepaid", "postpaid", "cash"].map((type) => {
              // جلب المنتج المقابل لهذا النوع
              const productForType = availableTransferTypes.find(
                (p) => p.transferType === type,
              );

              const Icon =
                type === "prepaid"
                  ? Smartphone
                  : type === "postpaid"
                    ? CreditCard
                    : Wallet;

              return (
                <button
                  key={type}
                  type="button"
                  onClick={() => {
                    if (productForType) {
                      setTransferType(type);
                      setAmount("");
                    }
                  }}
                  disabled={!productForType} // منع الضغط إذا المنتج غير موجود
                  className={`
          flex-1 py-3 rounded-xl font-black text-xs
          flex items-center justify-center gap-2
          transition-all
          ${transferType === type ? "bg-slate-700 text-red shadow" : ""}
          ${
            !productForType
              ? "opacity-30 cursor-not-allowed"
              : "text-white/40 hover:bg-white/5"
          }
        `}
                >
                  <Icon size={16} />
                  {TRANSFER_TYPE_LABEL[type]}
                </button>
              );
            })}
          </div>

          {/* Amount */}
          {/* Amount + Total */}
          {transferType && selectedProduct && (
            <div className="relative flex gap-3">
              {/* Quantity */}
              <div className="relative w-2/3 flex flex-col gap-1">
                <label>الكمية</label>
                <input
                  type="number"
                  placeholder="أدخل الكمية"
                  value={amount}
                  required
                  min={quantityField?.min ?? undefined}
                  max={quantityField?.max ?? undefined}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-5 py-4 rounded-xl border
    bg-white border-gray-200 outline-none
    dark:bg-black/20 dark:border-white/10"
                />
              </div>

              {/* Total */}
              <div className="w-1/3 flex flex-col gap-1">
                <label>السعر</label>

                <input
                  type="text"
                  readOnly
                  value={
                    amount && selectedProduct.price
                      ? (
                          parseFloat(amount) * parseFloat(selectedProduct.price)
                        ).toFixed(2)
                      : ""
                  }
                  placeholder="الإجمالي"
                  className=" w-full px-5 py-4 rounded-xl border outline-none
        bg-gray-100 dark:bg-black/20 border-gray-200 dark:border-white/10
        text-gray-700 dark:text-white font-bold"
                />
              </div>
            </div>
          )}

          {/* Submit */}
          <button
            disabled={!phoneNumber || !amount || !transferType || IsPending}
            className={`
              w-full py-5 rounded-xl font-black flex justify-center gap-3
              transition-all disabled:opacity-30
              ${
                selectedOperatorKey === "SYRIATEL"
                  ? "bg-gradient-to-r from-red-600 to-red-500 text-white"
                  : "bg-gradient-to-r from-yellow-500 to-yellow-400 text-black"
              }
            `}
          >
            {IsPending ? (
              <>
                <Spinner sm />
              </>
            ) : (
              <>
                <Send /> إرسال الطلب
              </>
            )}
          </button>

          {/* Tip */}
          <div className="flex gap-3 p-4 rounded-xl bg-white/5 border border-white/5 items-center">
            <Zap className="text-cyan-500" />
            <p className="text-[10px] opacity-40 font-bold">
              تأكد من صحة الرقم والمبلغ قبل الإرسال
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RaseedJomla;
